#include <stdio.h>
#include <iostream>
#include "MemberFunction.hpp"
using namespace std;

//Calculus operator+(const Calculus& cal,const Calculus cal2);

//This code includes ::
//We can overload operator using three ways
//Friend fnction  - If we want to access the private member of class thenwe will use this one
//Member function - If no constraint then simply add operator in class it self
//Non member function	- If no class member function and if no need to depend on privvate member of class then use non member function


	Calculus::Calculus()
	{

	}

	Calculus::Calculus(int val)
	{
		value=val;

	}
	
	int Calculus::getValue()
	{
		return value;
	}

	//Friend Function	
//	friend int operator+(const Calculus& cal,const Calculus calc2);

	//Member function
	int Calculus::operator+(Calculus& cal)
	{
		return this->value + cal.value;
	}

	int Calculus::operator+(int a,int b)
	{
		return a+b;
	}

/*
int operator+(const Calculus& cal,const Calculus calc2)
{

	return cal.value+ calc2.value;
}*/

//This is non member non friend function
Calculus operator+(const Calculus& cal,const Calculus cal2)
{

	return Calculus(cal.getValue() + cal2.getValue());
}

int main()
{
	Calculus cal(10);
	Calculus cal2(20);

	Calculus cal3=cal+cal2;
	cout<<"Value "<<cal3.getValue()<<endl;



	Calculus obj1(30);
	Calculus obj2(20);
	int value=obj1+obj2;
	cout<<"friend function returns " << value<<endl;
}
