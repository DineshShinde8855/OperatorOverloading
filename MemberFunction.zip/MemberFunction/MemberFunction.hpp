
class Calculus;
//Calculus operator+(const Calculus& cal,const Calculus cal2);

class Calculus
{
        int value;
   public:
        Calculus();
        Calculus(int val);
        int getValue();
	int operator+(Calculus& cal);
	int operator+(int a,int b);
}
Calculus operator+(const Calculus& cal,const Calculus cal2);
